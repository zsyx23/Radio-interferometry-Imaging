Python module API reference
===========================


Module ``rmsynthesis``
----------------------

.. automodule:: rmsynthesis
   :members:



Module ``rmsynthesis.main``
---------------------------

.. automodule:: rmsynthesis.main
   :members:


Module ``rmsynthesis.fits``
---------------------------
.. automodule:: rmsynthesis.fits
   :members:
